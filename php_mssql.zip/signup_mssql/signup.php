<?php
$serverName = "LAPTOP-3L9KMSG8\\SQLEXPRESS"; // CHANGE THIS
$connectionOptions = array(
    "Database" => "user_system"
);

$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Signup logic

if (isset($_POST['signup'])) {

    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, username, password) VALUES (?, ?, ?)";
    $params = array($name, $username, $password);

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo "<p style='color:red;'>Registration failed.</p>";
    } else {
        echo "<p style='color:green;'>Registration successful!</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
</head>
<body>

<h2>Sign Up</h2>

<form method="POST">
    <label>Name:</label><br>
    <input type="text" name="name" required><br><br>

    <label>Username:</label><br>
    <input type="text" name="username" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit" name="signup">Register</button>
</form>

</body>
</html>
