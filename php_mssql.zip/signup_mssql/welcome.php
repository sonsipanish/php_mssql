<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$serverName = "LAPTOP-3L9KMSG8\\SQLEXPRESS"; // CHANGE THIS
$connectionOptions = array(
    "Database" => "user_system"
);

$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}

/* ADD PRODUCT */
if (isset($_POST['add'])) {
    $name = $_POST['product_name'];
    $price = $_POST['price'];

    $sql = "INSERT INTO products (product_name, price) VALUES (?, ?)";
    $params = array($name, $price);
    sqlsrv_query($conn, $sql, $params);
}

/* DELETE PRODUCT */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM products WHERE id = ?";
    $params = array($id);
    sqlsrv_query($conn, $sql, $params);
}

/* EDIT PRODUCT */
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['product_name'];
    $price = $_POST['price'];

    $sql = "UPDATE products SET product_name = ?, price = ? WHERE id = ?";
    $params = array($name, $price, $id);
    sqlsrv_query($conn, $sql, $params);
}

/* FETCH PRODUCTS */
if (isset($_GET['search']) && $_GET['search'] != '') {
    $search = "%" . $_GET['search'] . "%";
    $sql = "SELECT * FROM products WHERE product_name LIKE ?";
    $params = array($search);
    $stmt = sqlsrv_query($conn, $sql, $params);
} else {
    $sql = "SELECT * FROM products";
    $stmt = sqlsrv_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>

<h2>Welcome, <?php echo $_SESSION['name']; ?>!</h2>
<a href="logout.php">Logout</a>

<hr>

<h3>Add Product</h3>
<form method="POST">
    <input type="text" name="product_name" placeholder="Product Name" required>
    <input type="number" step="1" name="price" placeholder="Price" required>
    <button type="submit" name="add">Add</button>
</form>

<hr>


<h3>Search Product</h3>
<form method="GET">
    <input type="text" name="search" placeholder="Search product name">
    <button type="submit">Search</button>
</form>

<h3>Product List</h3>

<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <th>Product</th>
        <th>Price</th>
        <th>Action</th>
    </tr>

<?php
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>".$row['id']."</td>";
    echo "<td>".$row['product_name']."</td>";
    echo "<td>".$row['price']."</td>";
    echo "<td>
        <a href='welcome.php?edit=".$row['id']."'>Edit</a> |
        <a href='welcome.php?delete=".$row['id']."' onclick='return confirm(\"Delete this product?\")'>Delete</a>
    </td>";
    echo "</tr>";
}
?>
</table>

<hr>

<?php
/* EDIT FORM */
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    $sql = "SELECT * FROM products WHERE id = ?";
    $params = array($id);
    $stmt = sqlsrv_query($conn, $sql, $params);
    $product = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
?>
<h3>Edit Product</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
    <input type="text" name="product_name" value="<?php echo $product['product_name']; ?>" required>
    <input type="number" step="1" name="price" value="<?php echo $product['price']; ?>" required>
    <button type="submit" name="update">Update</button>
</form>
<?php } ?>

</body>
</html>
